// Copyright 2018 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
package com.google.firebase.samples.apps.mlkit.java.textrecognition;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.util.Log;

import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.samples.apps.mlkit.common.GraphicOverlay;
import com.google.firebase.samples.apps.mlkit.common.GraphicOverlay.Graphic;

/**
 * Graphic instance for rendering TextBlock position, size, and ID within an associated graphic
 * overlay view.
 */
public class TextGraphic extends Graphic {

  private static final int TEXT_COLOR = Color.WHITE;
  private static final int[] COLOR_CHOICES = {
          Color.BLUE, Color.CYAN, Color.GREEN, Color.MAGENTA, Color.RED, Color.WHITE, Color.YELLOW
  };
  private static int currentColorIndex = 0;

  private static final float TEXT_SIZE = 96.0f;
  private static final float STROKE_WIDTH = 15.0f;

  private final Paint rectPaint;
  private final Paint rectPaint2;
  private final Paint textPaint;
  private final Paint idPaint;
  public final FirebaseVisionText.Element text;
  public final FirebaseVisionText.Element text2;

  private final TextGraphic2 textGraphic2;
  //private final TextDraw textDraw;

  public TextGraphic(GraphicOverlay overlay, FirebaseVisionText.Element text,
                     FirebaseVisionText.Element text2) {
    super(overlay);

    this.text = text;
    this.text2 = text2;

    rectPaint = new Paint();
    rectPaint.setColor(TEXT_COLOR);
    rectPaint.setStyle(Paint.Style.STROKE);
    rectPaint.setStrokeWidth(STROKE_WIDTH);

    rectPaint2 = new Paint();
    rectPaint2.setColor(Color.RED);
    rectPaint2.setStyle(Paint.Style.STROKE);
    rectPaint2.setStrokeWidth(STROKE_WIDTH);

    textPaint = new Paint();
    textPaint.setColor(TEXT_COLOR);
    textPaint.setTextSize(TEXT_SIZE);
    // Redraw the overlay, as this graphic has been added.
    //postInvalidate();

    currentColorIndex = (currentColorIndex + 1) % COLOR_CHOICES.length;
    final int selectedColor = COLOR_CHOICES[currentColorIndex];

    idPaint = new Paint();
    idPaint.setColor(selectedColor);
    textGraphic2 = new TextGraphic2(overlay, this.text);
    //textDraw = new TextDraw(overlay, text, text2);

  }

  /** Draws the text block annotations for position, size, and raw value on the supplied canvas. */
  @Override
  public void draw(Canvas canvas) {
      if (text == null) {
      throw new IllegalStateException("Attempting to draw a null text.");
    }

    if (text.getText().toLowerCase().contains("red")
            && text2.getText().toLowerCase().contains("hat")) {
      // Draws the bounding box around the TextBlock.
      RectF rect = new RectF(text.getBoundingBox());
      rect.left = translateX(rect.left);
      rect.top = translateY(rect.top);
      rect.right = translateX(rect.right);
      rect.bottom = translateY(rect.bottom);
      canvas.drawRect(rect, rectPaint);

      RectF rect2 = new RectF(text2.getBoundingBox());
      rect2.left = translateX(rect2.left);
      rect2.top = translateY(rect2.top);
      rect2.right = translateX(rect2.right);
      rect2.bottom = translateY(rect2.bottom);
      canvas.drawRect(rect2, rectPaint2);

        canvas.drawCircle(rect.centerX(),
                rect.centerY(),
                20f,
                idPaint);
        canvas.drawCircle(rect2.centerX(),
                rect2.centerY(),
                20f,
                idPaint);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        float pixelWidth = displayMetrics.widthPixels;
        //canvas.drawLine(rect.left, rect.centerY(), rect.right, rect.centerY(), textPaint);
        //canvas.drawLine(rect2.left, rect2.centerY(), rect2.right, rect2.centerY(), idPaint);
        canvas.drawLine(rect.centerX(), rect.centerY(), rect2.centerX(),
                rect2.centerY(),
            idPaint);

        Log.i("TAG", "textG 1 " + text.getText());
        Log.i("TAG", "Second text: " + text2.getText());
    }
  }

}
