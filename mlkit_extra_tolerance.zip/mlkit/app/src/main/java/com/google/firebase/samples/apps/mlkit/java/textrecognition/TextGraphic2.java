package com.google.firebase.samples.apps.mlkit.java.textrecognition;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;

import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.samples.apps.mlkit.common.GraphicOverlay;
import com.google.firebase.samples.apps.mlkit.common.GraphicOverlay.Graphic;

public class TextGraphic2 extends Graphic {

    private static final int TEXT_COLOR = Color.WHITE;
    private static final int[] COLOR_CHOICES = {
            Color.BLUE, Color.CYAN, Color.GREEN, Color.MAGENTA, Color.RED, Color.WHITE, Color.YELLOW
    };
    private static int currentColorIndex = 0;

    private static final float TEXT_SIZE = 54.0f;
    private static final float STROKE_WIDTH = 4.0f;

    private final Paint rectPaint;
    private final Paint textPaint;
    private final Paint idPaint;
    public final FirebaseVisionText.Element text;

    public TextGraphic2(GraphicOverlay overlay, FirebaseVisionText.Element text) {
        super(overlay);

        this.text = text;

        rectPaint = new Paint();
        rectPaint.setColor(TEXT_COLOR);
        rectPaint.setStyle(Paint.Style.STROKE);
        rectPaint.setStrokeWidth(STROKE_WIDTH);

        textPaint = new Paint();
        textPaint.setColor(TEXT_COLOR);
        textPaint.setTextSize(TEXT_SIZE);
        // Redraw the overlay, as this graphic has been added.
        postInvalidate();

        currentColorIndex = (currentColorIndex + 1) % COLOR_CHOICES.length;
        final int selectedColor = COLOR_CHOICES[currentColorIndex];

        idPaint = new Paint();
        idPaint.setColor(selectedColor);
    }

    @Override
    public void draw(Canvas canvas) {
        if (text == null) {
            throw new IllegalStateException("Attempting to draw a null text.");
        }

        /*if (text.getText().toLowerCase().contains("e")) {
            // Draws the bounding box around the TextBlock.
            RectF rect = new RectF(text.getBoundingBox());
            rect.left = translateX(rect.left);
            rect.top = translateY(rect.top);
            rect.right = translateX(rect.right);
            rect.bottom = translateY(rect.bottom);
            canvas.drawRect(rect, textPaint);

            if (text.getBoundingBox() != null) {
                canvas.drawCircle(translateX(text.getBoundingBox().centerX()),
                        translateY(text.getBoundingBox().centerY()),
                        20f,
                        idPaint);

                DisplayMetrics displayMetrics = new DisplayMetrics();
                float pixelWidth = displayMetrics.widthPixels;
                //canvas.drawLine(rect.left, rect.centerY(), rect.right, rect.centerY(), textPaint);
                //canvas.drawLine(rect2.left, rect2.centerY(), rect2.right, rect2.centerY(), idPaint);
            }
        } */
    }

}
