package com.google.firebase.samples.apps.mlkit.java.textrecognition;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.util.Log;

import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.samples.apps.mlkit.common.GraphicOverlay;

public class TextDraw extends GraphicOverlay.Graphic {
    private static final int TEXT_COLOR = Color.WHITE;
    private static final int[] COLOR_CHOICES = {
            Color.BLUE, Color.CYAN, Color.GREEN, Color.MAGENTA, Color.RED, Color.WHITE, Color.YELLOW
    };
    private static int currentColorIndex = 0;

    private static final float TEXT_SIZE = 96.0f;
    private static final float STROKE_WIDTH = 15.0f;

    private final Paint rectPaint;
    private final Paint rectPaint2;
    private final Paint textPaint;
    private final Paint idPaint;


    private final FirebaseVisionText.Element textGraphicText;
    private final FirebaseVisionText.Element textGraphicText2;
    TextGraphic textGraphic;
    TextGraphic2 textGraphic2;

    TextDraw(GraphicOverlay overlay, FirebaseVisionText.Element text1,
             FirebaseVisionText.Element text2) {
        super(overlay);
        this.textGraphicText = textGraphic.text;
        this.textGraphicText2 = textGraphic2.text;
        textGraphic = new TextGraphic(overlay, textGraphicText2, textGraphicText);
        textGraphic2 = new TextGraphic2(overlay, textGraphicText2);

        rectPaint = new Paint();
        rectPaint.setColor(TEXT_COLOR);
        rectPaint.setStyle(Paint.Style.STROKE);
        rectPaint.setStrokeWidth(STROKE_WIDTH);

        rectPaint2 = new Paint();
        rectPaint2.setColor(Color.RED);
        rectPaint2.setStyle(Paint.Style.STROKE);
        rectPaint2.setStrokeWidth(STROKE_WIDTH);

        textPaint = new Paint();
        textPaint.setColor(TEXT_COLOR);
        textPaint.setTextSize(TEXT_SIZE);
        // Redraw the overlay, as this graphic has been added.
        postInvalidate();

        currentColorIndex = (currentColorIndex + 1) % COLOR_CHOICES.length;
        final int selectedColor = COLOR_CHOICES[currentColorIndex];

        idPaint = new Paint();
        idPaint.setColor(selectedColor);
    }

    @Override
    public void draw(Canvas canvas) {

        if (textGraphicText == null) {
            throw new IllegalStateException("Attempting to draw a null text.");
        }

        if (textGraphicText.getText().toLowerCase().contains("re")) {
            // Draws the bounding box around the TextBlock.
            RectF rect = new RectF(textGraphicText.getBoundingBox());
            rect.left = translateX(rect.left);
            rect.top = translateY(rect.top);
            rect.right = translateX(rect.right);
            rect.bottom = translateY(rect.bottom);
            canvas.drawRect(rect, rectPaint);

            RectF rect2 = new RectF(textGraphicText2.getBoundingBox());
            rect2.left = translateX(rect2.left);
            rect2.top = translateY(rect2.top);
            rect2.right = translateX(rect2.right);
            rect2.bottom = translateY(rect2.bottom);
            canvas.drawRect(rect2, rectPaint2);

            canvas.drawCircle(rect.centerX(),
                    rect.centerY(),
                    20f,
                    idPaint);
            canvas.drawCircle(rect2.centerX(),
                    rect2.centerY(),
                    20f,
                    idPaint);

            DisplayMetrics displayMetrics = new DisplayMetrics();
            float pixelWidth = displayMetrics.widthPixels;
            //canvas.drawLine(rect.left, rect.centerY(), rect.right, rect.centerY(), textPaint);
            //canvas.drawLine(rect2.left, rect2.centerY(), rect2.right, rect2.centerY(), idPaint);
            canvas.drawLine(rect.centerX(), rect.centerY(), rect2.centerX(),
                    rect2.centerY(),
                    idPaint);

            Log.i("TAG", "textG 1 " + textGraphicText.getText());
            Log.i("TAG", "Second text: " + textGraphicText2.getText());
        }

    }
}
